package com.ifsp.app;

public class Aluno {

    private String Nome;
    private String Curso;
    private Integer Semestre;
    private String Linguagem;

    public Aluno(){

    }

    public Aluno(String nome, String curso, Integer semestre, String linguagem) {
        Nome = nome;
        Curso = curso;
        Semestre = semestre;
        Linguagem = linguagem;
    }


    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getCurso() {
        return Curso;
    }

    public void setCurso(String curso) {
        Curso = curso;
    }

    public Integer getSemestre() {
        return Semestre;
    }

    public void setSemestre(Integer semestre) {
        Semestre = semestre;
    }

    public String getLinguagem() {
        return Linguagem;
    }

    public void setLinguagem(String linguagem) {
        Linguagem = linguagem;
    }
}
