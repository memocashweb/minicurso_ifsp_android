package com.ifsp.app;

import android.app.ProgressDialog;
import android.content.Context;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class ClienteHTTP {

    private ProgressDialog PD;
    private Context context;
    private String URL;
    private Map<String, String> Parametros = new HashMap<String, String>();

    public ClienteHTTP(Context context ) {
        this.context = context;
        //AddParam("Cliente", Config.getValor( Configuracoes.IDCliente ));

        PD = new ProgressDialog( context );
        PD.setMessage("aguarde...");
        PD.setCancelable(false);
        PD.show();
    }


    public void AddParam(String Chave, String Valor){
        this.Parametros.put( Chave , Valor);
    }


    public void Enviar(String Acao, final OnEventListener<String> Retorno ){
        this.URL = "http://junior.memocashweb.com/?acao="+Acao;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, this.URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //RESPOSTA SUCESSO
                        PD.hide();
                        Retorno.Sucesso(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //ERRO
                        PD.hide();
                        Toast.makeText(context,error.toString(), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams(){
                return Parametros;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue( context );
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                180000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
    }
}
