package com.ifsp.app;

public interface OnEventListener<T> {
    public void Sucesso(T object);
    public void Falha(Exception e);
}