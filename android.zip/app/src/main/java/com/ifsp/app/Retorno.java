package com.ifsp.app;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class Retorno {

    private Boolean status;
    private JSONArray dados;
    private String msgem;

    public Retorno(Context context , String Dados ) {
        try{
            JSONObject dados_json = new JSONObject( Dados );
            status = dados_json.getBoolean( "Status" );
            dados  = dados_json.getJSONArray( "Dados" );
            msgem  = dados_json.getString( "Mensagem" );
        }catch( Exception e ){
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public JSONArray getDados() {
        return dados;
    }

    public void setDados(JSONArray dados) {
        this.dados = dados;
    }

    public String getMsgem() {
        return msgem;
    }

    public void setMsgem(String msgem) {
        this.msgem = msgem;
    }
}
