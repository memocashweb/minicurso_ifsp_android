package com.ifsp.app;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Context context;
    Toolbar toolbar;

    TextView Label_ListaVazia;

    EditText campoNome;
    EditText campoCurso;
    EditText campoSemestre;
    Spinner campoLinguagem;

    FloatingActionButton btnAtualizar;
    Button btnCadastrar;

    ListView viewAlunos;
    ArrayList<Aluno> listaAlunos;
    ArrayAdapter adapterAlunos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;


        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle( R.string.str_toolbar );

        btnCadastrar = findViewById(R.id.btn_cadastrar);
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Chama a funcao de cadastrar o aluno
                Cadastrar();
            }
        });

        btnAtualizar = findViewById(R.id.btn_atualizar);
        btnAtualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Chama a funcao de atualizar os dados
                AtualizarDados();
            }
        });

        viewAlunos    = findViewById(R.id.lista_alunos);
        listaAlunos   = new ArrayList<Aluno>() ;
        adapterAlunos = new adapterAlunos(this, listaAlunos);
        adapterAlunos.setNotifyOnChange( true );
        viewAlunos.setAdapter( adapterAlunos );

        campoNome      = findViewById(R.id.aluno_nome);
        campoCurso     = findViewById(R.id.aluno_curso);
        campoSemestre  = findViewById(R.id.aluno_semestre);
        campoLinguagem = findViewById(R.id.aluno_linguagem);

        List<String> linguagens = new ArrayList<>(Arrays.asList("Java","Python","PHP","Ruby"));
        ArrayAdapter<String> adapterSpiner =
                new ArrayAdapter<String>(
                        this, android.R.layout.simple_spinner_item, linguagens
                );
        adapterSpiner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        campoLinguagem.setAdapter(adapterSpiner);

        Label_ListaVazia = findViewById(R.id.label_lista_vazia);

        AtualizarDados();
    }



    private void AtualizarDados(){
        ClienteHTTP HTTP = new ClienteHTTP( context );
        HTTP.Enviar( "dados" ,new OnEventListener<String>() {
            @Override
            public void Sucesso(String resultado) {
                Log.e("resposta", resultado);
                //ACAO SUCESSO
                GerarLista(resultado);
            }
            @Override
            public void Falha(Exception e) {
                //ACAO FALHA
                Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } );
    }



    private void GerarLista(String Dados){
        Retorno ret = new Retorno( context ,Dados );

        Label_ListaVazia.setVisibility( View.VISIBLE );
        viewAlunos.setVisibility( View.GONE );

        try{
            JSONArray ret_dados = ret.getDados();


            listaAlunos.clear();
            for( int i =0; i < ret_dados.length(); i++ ){
                JSONObject objAluno = ret_dados.getJSONObject(i);

                Aluno aluno = new Aluno();
                aluno.setNome( objAluno.getString("Nome") );
                aluno.setCurso( objAluno.getString("Curso") );
                aluno.setSemestre( objAluno.getInt("Semestre") );
                aluno.setLinguagem( objAluno.getString("Linguagem") );
                listaAlunos.add(aluno);
            }
            adapterAlunos.notifyDataSetChanged();

            if( listaAlunos.size() > 0 ){
                Label_ListaVazia.setVisibility( View.GONE );
                viewAlunos.setVisibility( View.VISIBLE );
            }

        }catch( Exception e ){
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }



    private void Cadastrar(){
        ClienteHTTP HTTP = new ClienteHTTP( context );
        HTTP.AddParam("Nome", campoNome.getText().toString() );
        HTTP.AddParam("Curso", campoCurso.getText().toString() );
        HTTP.AddParam("Semestre", campoSemestre.getText().toString() );
        HTTP.AddParam("Linguagem", campoLinguagem.getSelectedItem().toString() );

        HTTP.Enviar( "cadastrar" ,new OnEventListener<String>() {
            @Override
            public void Sucesso(String resultado) {
                //ACAO SUCESSO
                Log.e("sucesso", resultado);
                GerarLista( resultado );
            }
            @Override
            public void Falha(Exception e) {
                //ACAO FALHA
                Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } );
    }






}
