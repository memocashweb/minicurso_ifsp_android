<?php
namespace App;


class Aluno{

    private $nome;
    private $curso;
    private $semestre;
    private $linguagem;

    /**
     * Aluno constructor.
     * @param $nome
     * @param $curso
     * @param $semestre
     * @param $linguagem
     */
    public function __construct( string $nome, string $curso, int $semestre, string $linguagem){
        $this->nome = $nome;
        $this->curso = $curso;
        $this->semestre = $semestre;
        $this->linguagem = $linguagem;
    }

    /**
     * @return string
     */
    public function getNome(): string{
        return $this->nome;
    }

    /**
     * @param string $nome
     */
    public function setNome(string $nome): void{
        $this->nome = $nome;
    }

    /**
     * @return string
     */
    public function getCurso(): string{
        return $this->curso;
    }

    /**
     * @param string $curso
     */
    public function setCurso(string $curso): void{
        $this->curso = $curso;
    }

    /**
     * @return int
     */
    public function getSemestre(): int{
        return $this->semestre;
    }

    /**
     * @param int $semestre
     */
    public function setSemestre(int $semestre): void{
        $this->semestre = $semestre;
    }

    /**
     */
    public function getLinguagem(): string{
        return $this->linguagem;
    }

    /**
     * @param string $linguagem
     */
    public function setLinguagem(string $linguagem): void{
        $this->linguagem = $linguagem;
    }




    public function getAluno(){
        return array(
            "Nome"      => self::getNome(),
            "Curso"     => self::getCurso(),
            "Semestre"  => self::getSemestre(),
            "Linguagem" => self::getLinguagem(),
        );
    }

}