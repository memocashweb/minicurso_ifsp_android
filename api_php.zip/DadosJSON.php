<?php
namespace App;


class DadosJSON{

    private $Dados;

    /**
     * DadosJSON constructor.
     * @param $Dados
     */
    public function __construct(){
        $this->Dados = json_decode( file_get_contents("dados.json"), true );
    }



    public function NovoAluno( Aluno $Aluno){
        $this->Dados[] = $Aluno->getAluno();
        self::SalvarArquivo();
    }



    public function SalvarArquivo(){
        file_put_contents( "dados.json", json_encode($this->Dados) );
    }


    public function getDados(){
        return $this->Dados;
    }

}