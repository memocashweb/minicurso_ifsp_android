<?php
header('Access-Control-Allow-Origin: *');

error_reporting( E_ALL );
ini_set( 'display_errors', 1);

require_once('DadosJSON.php');
require_once('Aluno.php');


use App\DadosJSON;
use App\Aluno;

$objJSON = new DadosJSON();
$Acao    = (string)$_GET['acao'];
$Dados   = $_POST;

$Resposta = array(
    "Status"   => false,
    "Dados"    => [],
    "Mensagem" => "",
);

switch( strtoupper($Acao) ){

    case 'CADASTRAR':
        $Resposta['Status'] = true;

        $objAluno = new Aluno( $Dados['Nome'], $Dados['Curso'], $Dados['Semestre'], $Dados['Linguagem'] );
        $objJSON->NovoAluno( $objAluno );

        $Resposta['Dados']  = $objJSON->getDados();
        break;

    case 'DADOS':
        $Resposta['Status'] = true;
        $Resposta['Mensagem'] = "Atualizado com sucesso.";
        $Resposta['Dados']  = $objJSON->getDados();
        break;

    default:
        $Resposta['Mensagem'] = "Solicitação não encontrada.";
}

echo json_encode( $Resposta );